import java.util.Scanner;

public class Evenorodd {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Check if number is even or odd
        System.out.print("Enter a number: ");
        int num = scanner.nextInt();
        if (num % 2 == 0)
            System.out.println("Even");
        else
            System.out.println("Odd");

        scanner.close();
    }
}
