import java.util.Scanner;

public class SumofElements {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Taking input for number of rows and columns
        System.out.print("Enter number of rows and columns: ");
        int rows = input.nextInt();
        int cols = input.nextInt();

        int[][] numbers = new int[rows][cols];
        int sum = 0;

        // Taking input for array elements and calculating sum
        System.out.println("Enter the elements:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                numbers[i][j] = input.nextInt();
                sum += numbers[i][j];
            }
        }

        // Displaying the sum
        System.out.println("Total Sum: " + sum);

        input.close();
    }
}
