import java.util.Scanner;

public class Print2DArray {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Input the number of rows and columns
        System.out.print("Enter the number of rows: ");
        int rows = input.nextInt();

        System.out.print("Enter the number of columns: ");
        int cols = input.nextInt();

        // Initialize the 2D array
        int[][] array = new int[rows][cols];

        // Input elements of the 2D array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print("Enter the element poisition(" + i + "," + j + "): ");
                array[i][j] = input.nextInt();
            }
        }

        // Print the 2D array
        System.out.println("\nThe 2D array is:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(" " + array[i][j]);
            }
            System.out.println(); // Move to the next line after printing each row
        }

        input.close();
    }
}
