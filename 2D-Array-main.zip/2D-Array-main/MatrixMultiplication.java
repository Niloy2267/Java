import java.util.Scanner;

public class MatrixMultiplication {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Taking input for number of rows and columns for the first matrix
        System.out.print("Enter the number of rows for the first matrix: ");
        int rows1 = input.nextInt();
        System.out.print("Enter the number of columns for the first matrix: ");
        int cols1 = input.nextInt();

        // Taking input for number of rows and columns for the second matrix
        System.out.print("Enter the number of rows for the second matrix: ");
        int rows2 = input.nextInt();
        System.out.print("Enter the number of columns for the second matrix: ");
        int cols2 = input.nextInt();

        // Check if multiplication is possible (columns of first matrix should be equal
        // to rows of second matrix)
        if (cols1 != rows2) {
            System.out.println(
                    "Matrix multiplication is not possible. Number of columns of first matrix must be equal to number of rows of second matrix.");
            return; // Exit the program if multiplication is not possible
        }

        // Declare matrices
        int[][] matrix1 = new int[rows1][cols1];
        int[][] matrix2 = new int[rows2][cols2];
        int[][] resultMatrix = new int[rows1][cols2];

        // Taking input for elements of the first matrix
        System.out.println("Enter the elements of the first matrix:");
        for (int i = 0; i < rows1; i++) {
            for (int j = 0; j < cols1; j++) {
                matrix1[i][j] = input.nextInt();
            }
        }

        // Taking input for elements of the second matrix
        System.out.println("Enter the elements of the second matrix:");
        for (int i = 0; i < rows2; i++) {
            for (int j = 0; j < cols2; j++) {
                matrix2[i][j] = input.nextInt();
            }
        }

        // Matrix multiplication
        for (int i = 0; i < rows1; i++) {
            for (int j = 0; j < cols2; j++) {
                for (int k = 0; k < cols1; k++) {
                    resultMatrix[i][j] += matrix1[i][k] * matrix2[k][j];
                }
            }
        }

        // Displaying the result matrix
        System.out.println("\nProduct of the two matrices:");
        for (int i = 0; i < rows1; i++) {
            for (int j = 0; j < cols2; j++) {
                System.out.print(resultMatrix[i][j] + " ");
            }
            System.out.println();
        }

        input.close();
    }
}
