import java.util.Scanner;

public class RowColumnSum {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Taking input for number of rows and columns
        System.out.print("Enter the number of rows: ");
        int rows = input.nextInt();
        System.out.print("Enter the number of columns: ");
        int cols = input.nextInt();

        int[][] numbers = new int[rows][cols];

        // Taking input for array elements
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                numbers[i][j] = input.nextInt();
            }
        }

        // Calculating and printing row-wise sum
        System.out.println("\nRow-wise sum:");
        for (int i = 0; i < rows; i++) {
            int rowSum = 0; // Initialize sum for the current row
            for (int j = 0; j < cols; j++) {
                rowSum += numbers[i][j];
            }
            System.out.println("Sum of row " + (i + 1) + ": " + rowSum);
        }

        // Calculating and printing column-wise sum
        System.out.println("\nColumn-wise sum:");
        for (int j = 0; j < cols; j++) {
            int colSum = 0; // Initialize sum for the current column
            for (int i = 0; i < rows; i++) {
                colSum += numbers[i][j];
            }
            System.out.println("Sum of column " + (j + 1) + ": " + ": " + colSum);
        }

        input.close();
    }
}
