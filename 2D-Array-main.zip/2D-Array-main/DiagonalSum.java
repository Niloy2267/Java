import java.util.Scanner;

public class DiagonalSum {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Taking input for the matrix size
        System.out.print("Enter the size of square matrix (n x n): ");
        int n = input.nextInt();

        int[][] matrix = new int[n][n];

        // Taking input for matrix elements
        System.out.println("Enter the elements of the matrix:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = input.nextInt();
            }
        }

        int primarySum = 0, secondarySum = 0;

        // Calculating diagonal sums
        for (int i = 0; i < n; i++) {
            primarySum += matrix[i][i]; // Main Diagonal
            secondarySum += matrix[i][n - i - 1]; // Secondary Diagonal
        }

        // If n is odd, subtract the middle element (as it's counted twice)
        int totalSum = primarySum + secondarySum;
        if (n % 2 == 1) {
            totalSum -= matrix[n / 2][n / 2];
        }

        // Displaying the results
        System.out.println("Sum of Main Diagonal: " + primarySum);
        System.out.println("Sum of Secondary Diagonal: " + secondarySum);
        System.out.println("Total Sum: " + totalSum);

        input.close();
    }
}
