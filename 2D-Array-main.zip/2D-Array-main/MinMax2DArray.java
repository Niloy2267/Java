import java.util.Scanner;

public class MinMax2DArray {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Taking input for number of rows and columns
        System.out.print("Enter number of rows: ");
        int rows = input.nextInt();
        System.out.print("Enter number of columns: ");
        int cols = input.nextInt();

        int[][] numbers = new int[rows][cols];

        // Taking input for array elements
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                numbers[i][j] = input.nextInt();
            }
        }

        // Initialize min and max with first element
        int min = numbers[0][0];
        int max = numbers[0][0];

        // Finding min and max
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (numbers[i][j] < min) {
                    min = numbers[i][j];
                }
                if (numbers[i][j] > max) {
                    max = numbers[i][j];
                }
            }
        }

        // Printing the results
        System.out.println("Minimum element: " + min);
        System.out.println("Maximum element: " + max);

        input.close();
    }
}
